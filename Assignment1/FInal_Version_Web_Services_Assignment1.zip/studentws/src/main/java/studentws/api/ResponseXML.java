package studentws.api;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "response")
public class ResponseXML {
    private String status;
    private String message;

    @XmlElement
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @XmlElement
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}
