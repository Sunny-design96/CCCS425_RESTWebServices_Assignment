package studentws.api;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Unmarshaller;

import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.XMLConstants;
import java.io.File;

@Path("/submitXML")

public class StudentServlet {

    @GET
    @Produces(MediaType.APPLICATION_XML)
    public ResponseXML submitXML() {
        ResponseXML response = new ResponseXML();

        try {
            
            JAXBContext context = JAXBContext.newInstance(Student.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();

            
            SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            
            File xsdFile = new File(getClass().getClassLoader().getResource("student.xsd").toURI());
            Schema schema = sf.newSchema(xsdFile);
            unmarshaller.setSchema(schema);

            
            File xmlFile = new File(getClass().getClassLoader().getResource("input.xml").toURI());
            Student student = (Student) unmarshaller.unmarshal(xmlFile);


           
            response.setStatus("success");
            response.setMessage("XML data received and validated.");
            return response;

        } catch (Exception e) {
            
            e.printStackTrace();
            response.setStatus("error");
            response.setMessage("Invalid XML data.");
            return response;
        }
    }
}
